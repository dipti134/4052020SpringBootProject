package com.spring.bean.test;

public class Outer {
	
	public static class Inner {
		public void show() {
			System.out.println("showing static Inner class");
		}
	}

}
