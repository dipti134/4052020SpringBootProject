package com.spring.bean.test;

public class ParentHome {
	private String homeAddress;

	public String getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}

}
