package com.spring.bean.test;

public class Demo1 {

	public void print() {
		System.out.println("Called Demo1 Class");
	}

}
