package com.spring.bean.test;

public abstract class AbstractNameFactory {
    public abstract Name createName();
}
